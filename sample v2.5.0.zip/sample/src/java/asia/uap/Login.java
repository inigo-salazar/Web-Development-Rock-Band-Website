/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asia.uap;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;

/**
 *
 * @author User
 */
@WebServlet(name = "Login", urlPatterns = {"/do.login"})
public class Login extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        ArrayList<Profile> prs = new ArrayList();
        Boolean profile_found = false;
        Boolean passmatch = false;
        Boolean success = false;
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        if (username == null || username.isEmpty() || password == null || password.isEmpty())
        {
            response.sendRedirect("login.jsp?error=missing or invalid fields");
            return;
        }
        HttpSession session = request.getSession();
        prs = (ArrayList) session.getAttribute("profile");
        Profile p = new Profile();
        if (prs == null || prs.isEmpty()){
            response.sendRedirect("login.jsp?error=create an account");
            return;
        }
        else
        {
            for (Profile i : prs)
            {
                if(i.getUsername().equals(username))
                {
                    profile_found = true;
                    p = i;
                    break;
                }
            }
            if (profile_found == false)
            {
                response.sendRedirect("login.jsp?error=User does not exist");
                return;
            }
            else
            {
                if(p.getPassword().equals(password))
                {
                    success = true;
                    session.setAttribute("currentprofile", p);
                    session.setAttribute("username", p.getUsername());
                    session.setAttribute("password", p.getPassword());
                    session.setAttribute("fn", p.getFn());
                    session.setAttribute("ln", p.getLn());
                    session.setAttribute("email", p.getEmail());
                    if(p.getPassword().equals("adminpass") && p.getUsername().equals("admin"))
                    {
                        response.sendRedirect("admin/admin.jsp");
                        return;
                    }
                    else
                    {
                        response.sendRedirect("home.jsp");
                        return;
                    }
                }
                else
                {
                    response.sendRedirect("login.jsp?error=password does not match");
                }
            }
        }
       
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
