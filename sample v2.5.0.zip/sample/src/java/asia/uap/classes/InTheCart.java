/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asia.uap.classes;

/**
 *
 * @author User
 */
public class InTheCart 
{
    private int id = 0;
    private String itemName;
    private String description;
    private String picture;
    private int qty = 0;
    private double price = 0.00;
    private double item_subtotal = 0.00;
    
    //shirt
    
    private String size;

    /**
     * @return the id
     */
    public InTheCart(int id, String itemName, String picture, String description, int qty, double price)
    {
        this.id = id;
        this.itemName = itemName;
        this.picture = picture;
        this.description = description;
        this.qty = qty;
        this.price = price;
    }
    
    
    
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the itemName
     */
    public String getItemName() {
        return itemName;
    }

    /**
     * @param itemName the itemName to set
     */
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * @return the qty
     */
    public int getQty() {
        return qty;
    }

    /**
     * @param qty the qty to set
     */
    public void setQty(int qty) {
        this.qty = qty;
    }

    /**
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * @return the cart_subtotal
     */
    public double getItem_subtotal() {
        return item_subtotal;
    }

    /**
     * @param cart_subtotal the cart_subtotal to set
     */
    public void setItem_subtotal(double cart_subtotal) {
        this.item_subtotal = item_subtotal;
    }
    
    public void setItem_subtotal()
    {
        this.setItem_subtotal(this.getPrice() * this.getQty());
    }

    /**
     * @return the size
     */
    public String getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(String size) {
        this.size = size;
    }

    /**
     * @return the picture
     */
    public String getPicture() {
        return picture;
    }

    /**
     * @param picture the picture to set
     */
    public void setPicture(String picture) {
        this.picture = picture;
    }
}
