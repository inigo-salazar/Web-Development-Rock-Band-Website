/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asia.uap.classes;

/**
 *
 * @author User
 */
public class Item 
{
    private int id;
    private String itemName;
    private String description;
    private int qty;
    private double price;
    private String picture;
    
    //for clothes
    private String size;
    
    public Item(int id, String itemName, String picture, String description, int qty, double price)
    {
        this.id = id;
        this.itemName = itemName;
        this.picture = picture;
        this.description = description;
        this.qty = qty;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemName() 
    {
        return itemName;
    }
    public void setItemName(String itemName) 
    {
        this.itemName = itemName;
    }

    public String getDescription() 
    {
        return description;
    }

    public void setDescription(String description) 
    {
        this.description = description;
    }
    public int getQty() 
    {
        return qty;
    }

    public void setQty(int qty) 
    {
        this.qty = qty;
    }

    public double getPrice() 
    {
        return price;
    }

    public void setPrice(double price) 
    {
        this.price = price;
    }

    public String getSize() 
    {
        return size;
    }

    public void setSize(String size) 
    {
        this.size = size;
    }
    
    public String getPicture() {
        return picture;
    }

    /**
     * @param picture the picture to set
     */
    public void setPicture(String picture) {
        this.picture = picture;
    }
}
