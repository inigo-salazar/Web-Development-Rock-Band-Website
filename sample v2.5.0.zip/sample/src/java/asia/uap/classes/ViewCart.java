/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asia.uap.classes;

/**
 *
 * @author User
 */
import java.util.ArrayList;

public class ViewCart 
{
    private double cart_subtotal;
    private ArrayList<InTheCart> itemslist = new ArrayList<>();
    
    public void AddToCart(int id, String itemName, String picture, String description, int qty, double price)
    {
        InTheCart itc = new InTheCart(id, itemName, picture, description, qty, price);
    }
    
    private void calculateCost() 
    {
        double cart_subtotal = 0.0;
	for(InTheCart itc : itemslist) 
        {
            cart_subtotal += itc.getItem_subtotal();
	}
	this.setSubCart(cart_subtotal);	
    }
    public void setSubCart(double cart_subtotal) 
    {
	this.cart_subtotal = cart_subtotal;
    }

    public double getSubCart() 
    {
        return this.cart_subtotal;
    }
    
    public int getNumOfItems() 
    {
        return this.itemslist.size();
    }
}
